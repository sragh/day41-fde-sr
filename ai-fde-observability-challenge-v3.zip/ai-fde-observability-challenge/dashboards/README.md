# Dashboard Workspace

No production dashboard is provided initially. Participants are expected to design or generate the unified production health view as part of the challenge.
