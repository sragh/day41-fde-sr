import time
import uuid

from fastapi import FastAPI, HTTPException

from app.models import CaseApplication, CaseDecision
from app.observability.logging import event
from app.observability.metrics import inc, set_gauge, snapshot
from app.observability.tracing import span
from app.services.audit import write_audit
from app.services.data_service import get_customer
from app.services.decision import decide
from app.services.identity import verify_identity
from app.services.risk_model import infer

app = FastAPI(title="DecisionStream AI", version="1.0.0")


@app.get("/health")
def health():
    return {"status": "ok"}


@app.post("/case-application", response_model=CaseDecision)
def case_application(case: CaseApplication):
    trace_id = str(uuid.uuid4())
    start = time.perf_counter()

    with span("POST /case-application", trace_id=trace_id, case_id=case.case_id):
        inc("case_requests")
        event(
            "case.received",
            trace_id=trace_id,
            case_id=case.case_id,
            customer_id=case.customer_id,
        )

        if not verify_identity(case.case_id, case.customer_id, trace_id):
            inc("case_errors")
            raise HTTPException(status_code=400, detail="identity failed")

        customer = get_customer(case.customer_id, trace_id, case.case_id)
        if not customer:
            inc("case_errors")
            raise HTTPException(status_code=404, detail="customer not found")

        score, model_version, tokens, retry_count = infer(case, customer, trace_id)
        decision, reason = decide(case.case_id, score, model_version, trace_id)

        write_audit(
            case.case_id,
            trace_id,
            decision,
            model_version,
            model_retry_count=retry_count,
        )

        inc(f"decision_{decision.lower()}")

        # Intentional workshop weakness: only last-value gauges are retained,
        # so percentile/SLO analysis cannot be performed correctly yet.
        set_gauge(
            "last_case_latency_ms",
            round((time.perf_counter() - start) * 1000, 2),
        )
        set_gauge("last_case_tokens", tokens)

        return CaseDecision(
            case_id=case.case_id,
            decision=decision,
            risk_score=score,
            model_version=model_version,
            reason=reason,
        )


@app.get("/metrics-snapshot")
def metrics_snapshot():
    return snapshot()
