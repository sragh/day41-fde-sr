from collections import defaultdict

COUNTERS = defaultdict(int)
GAUGES = {}

def inc(name: str, value: int = 1): COUNTERS[name] += value

def set_gauge(name: str, value): GAUGES[name] = value

def snapshot(): return {'counters': dict(COUNTERS), 'gauges': dict(GAUGES)}
# Intentional gaps: no labels, histograms, P95, SLO windows, or export format.
