import uuid, time
from contextlib import contextmanager
from .logging import event

@contextmanager
def span(name: str, trace_id: str | None = None, case_id: str | None = None):
    # Intentional gap: each missing trace_id creates a fresh trace, breaking end-to-end correlation.
    tid = trace_id or str(uuid.uuid4())
    sid = str(uuid.uuid4())[:8]
    start = time.perf_counter()
    event('span.start', span=name, trace_id=tid, span_id=sid, case_id=case_id)
    status = 'OK'
    try:
        yield {'trace_id': tid, 'span_id': sid}
    except Exception:
        status = 'ERROR'
        raise
    finally:
        event('span.end', span=name, trace_id=tid, span_id=sid, case_id=case_id,
              status=status, duration_ms=round((time.perf_counter()-start)*1000,2))
