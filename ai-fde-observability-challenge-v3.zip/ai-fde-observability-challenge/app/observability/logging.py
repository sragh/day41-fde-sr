import json, logging, sys

logger = logging.getLogger('decisionstream')
handler = logging.StreamHandler(sys.stdout)
handler.setFormatter(logging.Formatter('%(message)s'))
logger.handlers = [handler]
logger.setLevel(logging.INFO)

def event(name: str, **fields):
    # Intentional gap: no automatic trace_id/case_id propagation or PII redaction.
    logger.info(json.dumps({'event': name, **fields}, default=str))
