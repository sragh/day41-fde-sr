import json
import time
from pathlib import Path

from app.observability.logging import event
from app.observability.metrics import inc
from app.observability.tracing import span

CONFIG_PATH = Path(__file__).resolve().parents[2] / "config" / "model_config.json"


def _load_model_config() -> dict:
    with CONFIG_PATH.open(encoding="utf-8") as handle:
        return json.load(handle)


def infer(case, customer, trace_id: str):
    config = _load_model_config()["current"]
    model_version = config["version"]

    with span("risk_model.invoke", trace_id=trace_id, case_id=case.case_id):
        attempts = 2 if case.case_id == "CASE-1042" else 1
        tokens_total = 0
        score = 0.0

        for attempt in range(1, attempts + 1):
            with span(
                f"risk_model.attempt.{attempt}",
                trace_id=trace_id,
                case_id=case.case_id,
            ):
                time.sleep(0.16 if attempt == 1 else 0.32)
                tokens = 1350 if attempt == 1 else 1600
                tokens_total += tokens
                inc("model_calls")

                if case.case_id == "CASE-1042" and attempt == 1:
                    event(
                        "model.retry",
                        case_id=case.case_id,
                        attempt=attempt,
                        reason="timeout",
                    )
                    continue

                debt_ratio = case.amount / max(case.income, 1)
                score = min(
                    0.99,
                    config["base_score"]
                    + debt_ratio * config["debt_weight"]
                    + (
                        config["foreign_country_penalty"]
                        if case.country != "IN"
                        else 0
                    ),
                )

        # Intentional observability gaps for the workshop:
        # - token usage is only surfaced in an event and a last-value gauge at the API layer
        # - no per-model latency distribution
        # - sensitive prompt-like features are logged without redaction
        event(
            "model.result",
            case_id=case.case_id,
            model_version=model_version,
            tokens=tokens_total,
            risk_score=round(score, 3),
            customer_income=case.income,
            requested_amount=case.amount,
        )
        retry_count = max(0, attempts - 1)
        return score, model_version, tokens_total, retry_count
