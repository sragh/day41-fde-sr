from app.observability.tracing import span
from app.observability.logging import event


def decide(case_id: str, risk_score: float, model_version: str, trace_id: str):
    with span('decision.rules', trace_id=trace_id, case_id=case_id):
        if risk_score < 0.45:
            decision, reason = 'APPROVE', 'risk below threshold'
        elif risk_score < 0.70:
            decision, reason = 'REVIEW', 'manual review required'
        else:
            decision, reason = 'REJECT', 'risk above threshold'
        event('business.decision', case_id=case_id, decision=decision,
              model_version=model_version, risk_score=risk_score)
        return decision, reason
