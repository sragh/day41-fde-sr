import time
from app.observability.logging import event
from app.observability.tracing import span

SLOW_CASES = {'CASE-1042','CASE-2048'}

def verify_identity(case_id: str, customer_id: str, trace_id: str | None = None) -> bool:
    # BUG: trace_id intentionally not forwarded into span -> fragmented trace.
    with span('identity.verify', case_id=case_id):
        delay = 0.82 if case_id in SLOW_CASES else 0.05
        time.sleep(delay)
        event('identity.result', case_id=case_id, customer_id=customer_id, passed=True)
        return True
