import json
from datetime import datetime, timezone
from pathlib import Path

from app.observability.tracing import span

AUDIT = Path(__file__).resolve().parents[2] / "data" / "audit_log.jsonl"


def write_audit(
    case_id: str,
    trace_id: str,
    decision: str,
    model_version: str,
    model_retry_count: int = 0,
):
    with span("audit.write", trace_id=trace_id, case_id=case_id):
        record = {
            "ts": datetime.now(timezone.utc).isoformat(),
            "case_id": case_id,
            "trace_id": trace_id,
            "decision": decision,
            "model_version": model_version,
        }

        # Intentional workshop gap: retry evidence is not persisted for the
        # seeded incident, creating an audit/provenance completeness problem.
        if model_retry_count and case_id != "CASE-1042":
            record["model_retry_count"] = model_retry_count

        with AUDIT.open("a", encoding="utf-8") as handle:
            handle.write(json.dumps(record) + "\n")
