# Runbook Workspace

No incident runbook is provided initially. Participants are expected to create alert response and recovery runbooks during the challenge.
